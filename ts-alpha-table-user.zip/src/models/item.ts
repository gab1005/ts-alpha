type Item = {
  id?: number;
  nome: string;
  data_nascimento: string;
  email: string;
  cpf: string;
};
export default Item;
